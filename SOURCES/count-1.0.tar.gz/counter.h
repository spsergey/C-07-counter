#include <stdio.h>
#include <unistd.h>
#include <getopt.h>

typedef int bool;
#define false 0
#define true 1

void counter(int mas[3]);

